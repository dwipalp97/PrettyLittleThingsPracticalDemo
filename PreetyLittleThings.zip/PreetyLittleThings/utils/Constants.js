export const PRODUCT_IMAGE_BASE_URL = "https://cdn-img.prettylittlething.com/"
export const API_BASE_URL = "https://my-json-server.typicode.com/benirvingplt/"