
import * as HomeActions from './actions';

const initialState = {
    products: [],
    isLoading: false,
};

export default function reducer(state = initialState, action) {
    switch (action.type) {
        case HomeActions.FETCH_PRODUCT_LIST: {
            return {
                isLoading: true,
            }
        }
        case HomeActions.FETCH_PRODUCT_LIST_RESULT: {
            return {
                isLoading: false,
                products: action.payload.data
            }
        }
        default:
            return state;
    }
}