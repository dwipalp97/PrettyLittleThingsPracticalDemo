export const FETCH_PRODUCT_LIST = 'FETCH_PRODUCT_LIST';
export const FETCH_PRODUCT_LIST_RESULT = 'FETCH_PRODUCT_LIST_RESULT';

function fetchProductList() {
  return {
    type: FETCH_PRODUCT_LIST
  };
}

function fetchProductListResult(payload) {
    return {
      type: FETCH_PRODUCT_LIST_RESULT,
      payload
    };
  }