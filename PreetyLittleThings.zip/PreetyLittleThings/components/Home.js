import React, {useEffect} from 'react'
import {
    FlatList,
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    Platform
  } from 'react-native';
  import * as Constants  from "../utils/Constants";


export function Home() {

    useEffect(()=> {
        getProductList();
    },[]);

    // get product list
    const getProductList = () =>{


    }

    const productItemRender = (item) => {

        return (
            <View style={style.productContainer}>
                <Image 
                style = {style.productImage} 
                source={`${item.img}`}/>
                <Text 
                    style= {style.productTitle}>
                        {item.name}
                </Text>
                <Text 
                    style= {style.productPrice}>
                        {item.price}
                </Text>
            </View>
        )
    }

    return(
        <View style={style.container}>


        </View>
    )
} 

const style = StyleSheet.create({
    container: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      padding: 10
    }, 
    productContainer: {
        flex:1,
        padding:15,
        borderRadius:10,
        backgroundColor:"white",
    },
    productTitle: {
        fontSize:14,
        color:"black"
    },
    productPrice: {
        fontSize:16,
        color:"black",
        fontWeight: '300',
        alignSelf:'flex-end'
    },
    productImage: {
        height: 200
    }
  })