import Axios from "axios";
import { API_BASE_URL } from "../utils/Constants";

export const getProductList = () => {
    return Axios.get(`${API_BASE_URL}products/products`,)
      .then(response => response)
      .catch((error) => error.response);
  }
  